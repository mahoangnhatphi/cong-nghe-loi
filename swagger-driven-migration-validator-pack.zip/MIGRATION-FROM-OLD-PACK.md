# Migration From Previous Skill Pack

The previous direction was broad and JSON-heavy.

## Old Direction

```text
large JSON response
  ↓
auto field matching
  ↓
generic validator
```

## New Direction

```text
Swagger/OpenAPI specs
  ↓
API matching
  ↓
api-map.yaml
  ↓
Node.js batch validation by params.csv
```

## Keep If Needed

You can still reuse these concepts:

- api-authentication
- api-client-retry-timeout
- text-storage
- report-generation

## Not Needed First

These are optional now:

- auto-field-matching
- sqlite-storage
- generic record-matching-strategy
- large-data-performance

Start with Swagger-driven API matching first. Less guessing, fewer token sacrifices, fewer meetings where people stare at mismatches like cave paintings.
