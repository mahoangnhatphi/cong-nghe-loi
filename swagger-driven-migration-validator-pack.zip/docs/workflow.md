# Workflow

## Step 1

Replace these sample files with your real Swagger/OpenAPI specs:

```text
config/old-openapi.yaml
config/new-openapi.yaml
```

## Step 2

Generate API mapping proposal:

```bash
migval match-api \
  --old config/old-openapi.yaml \
  --new config/new-openapi.yaml \
  --out config/api-map.proposed.yaml
```

## Step 3

Review proposal and create:

```text
config/api-map.yaml
```

Fix:

- paths
- methods
- response_path
- merge_as
- param_binding
- field_mappings

## Step 4

Prepare:

```text
config/params.csv
```

Example:

```csv
employeeId
EMP001
EMP002
EMP003
```

## Step 5

Run validation:

```bash
migval run --api-map config/api-map.yaml --params config/params.csv
```

## Step 6

Review:

```text
output/runs/<run-id>/
├── summary.txt
├── mismatches.csv
├── mismatches.jsonl
├── errors.jsonl
└── report.html
```
