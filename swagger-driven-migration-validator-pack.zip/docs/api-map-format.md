# API Map Format

`config/api-map.yaml` is the center of the validator.

## Example

```yaml
api_matches:
  - name: employee_full_validation
    match_type: one_to_many

    legacy:
      system: old
      operation_id: getEmployeeFull
      method: GET
      path: /api/employee/full/{employeeId}
      response_path: data

    targets:
      - system: new
        operation_id: getEmployeeBasic
        method: GET
        path: /api/v2/employees/{employeeId}
        response_path: data.employee
        merge_as: employee

    param_binding:
      employeeId: employeeId

    field_mappings:
      - legacy: employeeCode
        target: employee.code
        type: string
```

## Meaning

| Field | Meaning |
|---|---|
| name | validation scenario name |
| match_type | one_to_one, one_to_many, many_to_one, many_to_many |
| legacy | old API call definition |
| targets | new API call definitions |
| response_path | where useful data lives inside response |
| merge_as | key used to merge target response |
| param_binding | maps API parameter to CSV column |
| field_mappings | compares old field to merged target field |
