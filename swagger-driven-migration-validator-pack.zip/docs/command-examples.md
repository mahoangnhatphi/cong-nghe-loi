# Command Examples

## Doctor

```bash
migval doctor --config config
```

## Generate API Mapping Proposal

```bash
migval match-api \
  --old config/old-openapi.yaml \
  --new config/new-openapi.yaml \
  --out config/api-map.proposed.yaml
```

## Run Validation

```bash
migval run \
  --api-map config/api-map.yaml \
  --params config/params.csv
```

## Generate Report

```bash
migval report --run output/runs/latest
```

## Environment Variables

Linux/macOS:

```bash
export OLD_API_TOKEN="old-token"
export NEW_API_TOKEN="new-token"
```

Windows PowerShell:

```powershell
$env:OLD_API_TOKEN="old-token"
$env:NEW_API_TOKEN="new-token"
```
