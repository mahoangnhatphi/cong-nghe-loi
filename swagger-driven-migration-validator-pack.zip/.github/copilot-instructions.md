# Copilot Instructions

## Goal

Build a Swagger-driven migration validation tool.

The user already has Swagger/OpenAPI specs for old and new APIs.

## Rules

- Use OpenAPI specs as the primary source for API matching.
- Do not require pasting huge JSON responses into chat.
- Generate editable config files.
- Keep API matching in `config/api-map.yaml`.
- Keep batch input in `config/params.csv`.
- Keep auth in `config/auth.yaml`.
- Use Node.js 20+ with TypeScript.
- Prefer CLI-first design.
- Write reports as TXT, CSV, JSONL, and HTML.
- Do not hardcode URLs, tokens, endpoint paths, params, or field mappings.

## Runtime Flow

For each row in `params.csv`:

1. Call legacy API.
2. Call mapped target APIs.
3. Extract data using `response_path`.
4. Merge target responses using `merge_as`.
5. Compare fields using `field_mappings`.
6. Write report rows.

## Avoid

- raw JSON equality comparison
- array-index matching unless explicitly configured
- auto-accepting uncertain API matches
- logging secrets
- dumping full payloads into HTML reports
