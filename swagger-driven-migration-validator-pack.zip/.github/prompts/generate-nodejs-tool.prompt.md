# Prompt: Generate Node.js Tool

Read all skills under `.copilot/skills`.

Generate a complete Node.js 20 TypeScript CLI tool named `migval`.

Commands:

```bash
migval doctor
migval match-api
migval run
migval report
```

The tool must use:

- OpenAPI specs for API matching
- api-map.yaml for validation runtime
- params.csv for batch input
- auth.yaml for auth
- text file reports

Output source code and explain how to run it.
