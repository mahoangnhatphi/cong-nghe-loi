# Prompt: Review API Map

Read:

- `.copilot/skills/swagger-api-matching.md`
- `.copilot/skills/swagger-response-compare.md`

Review `config/api-map.yaml`.

Check:

1. old endpoint path and method
2. target endpoint paths and methods
3. match_type
4. param_binding
5. query params
6. response_path
7. merge_as names
8. field_mappings
9. compare types
10. missing mappings
11. risky mappings
12. unclear one-to-many matches

Return:

- critical issues
- warnings
- suggested fixes
- improved YAML snippets
