# Prompt: Generate API Map

Read:

- `.copilot/skills/swagger-api-matching.md`
- `.copilot/skills/swagger-response-compare.md`

Given:

- `config/old-openapi.yaml`
- `config/new-openapi.yaml`

Generate:

- `config/api-map.proposed.yaml`

Rules:

- Match old operations to new operations.
- Support one-to-one and one-to-many matches.
- Include confidence score.
- Include reasons.
- Include param_binding.
- Include response_path placeholders.
- Include merge_as for target APIs.
- Include field_mappings if schema fields are clear.
- Mark uncertain matches as `needs_review`.
