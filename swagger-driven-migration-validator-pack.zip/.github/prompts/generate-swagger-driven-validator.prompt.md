# Prompt: Generate Swagger-Driven Migration Validator

Read `.copilot/skills/00-skill-index.md` first.

Then read all related skills under `.copilot/skills`.

Generate a Node.js 20 TypeScript CLI tool named `migval`.

The user already has old and new Swagger/OpenAPI specs.

Requirements:

- parse old OpenAPI and new OpenAPI
- suggest API matches
- generate `config/api-map.proposed.yaml`
- allow human-reviewed `config/api-map.yaml`
- run validation for params from `config/params.csv`
- call old API and new split APIs
- merge target responses using `merge_as`
- extract response data using `response_path`
- compare fields using `field_mappings`
- support bearer token, API key, basic auth, and custom headers
- support retry and timeout
- write TXT, CSV, JSONL, and HTML reports
- keep large responses local

Generate:

1. project structure
2. package.json
3. tsconfig.json
4. TypeScript source files
5. config examples
6. command examples
7. test plan
