# Text Storage

## Purpose

Persist validation results as files, not a database.

Use:

- JSON
- JSONL
- CSV
- TXT
- HTML
- compressed raw files if needed

## Output Folder

```text
output/runs/<run-id>/
├── run-metadata.json
├── config-hash.txt
├── summary.txt
├── api-results.jsonl
├── mismatches.jsonl
├── mismatches.csv
├── errors.jsonl
├── report.json
├── report.html
└── raw/
```

## Rules

- Use JSONL for append-only large data.
- Use CSV for Excel-friendly review.
- Use TXT for summary.
- Use HTML for readable report.
- Do not store secrets.
- Redact auth headers and tokens.

## Raw Responses

Optional:

```yaml
raw_response:
  enabled: false
  folder: raw
  compression: gzip
```

## Assistant Behavior

- create text storage writer
- support append JSONL
- support CSV
- write summary at end
- write report.html
- avoid storing all records in memory
- redact secrets
