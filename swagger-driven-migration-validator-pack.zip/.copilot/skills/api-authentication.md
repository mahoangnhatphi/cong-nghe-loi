# API Authentication

## Purpose

Configure authentication for old and new APIs.

## Supported Types

Bearer:

```yaml
auth_profiles:
  old_bearer:
    type: bearer
    token_env: OLD_API_TOKEN
```

API key:

```yaml
auth_profiles:
  new_api_key:
    type: api_key
    in: header
    name: x-api-key
    value_env: NEW_API_KEY
```

Basic:

```yaml
auth_profiles:
  old_basic:
    type: basic
    username_env: OLD_API_USERNAME
    password_env: OLD_API_PASSWORD
```

Custom headers:

```yaml
auth_profiles:
  custom:
    type: custom_headers
    headers:
      x-tenant-id:
        value: tenant-a
      x-client-id:
        env: CLIENT_ID
```

## System Binding

```yaml
systems:
  old:
    base_url: https://old.example.com
    auth_ref: old_bearer

  new:
    base_url: https://new.example.com
    auth_ref: new_api_key
```

## Rules

- Never hardcode secrets.
- Read secrets from environment variables.
- Redact secrets in logs.
- Fail fast if required env vars are missing.
- Support different auth profiles per system.

## Assistant Behavior

- create auth provider interface
- create implementation per auth type
- inject auth headers into API client
- validate env vars in `doctor`
- redact secrets in request logs
