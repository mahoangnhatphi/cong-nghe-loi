# Skill Index

## Purpose

This pack supports Swagger-driven API migration validation.

## Skill Map

```text
swagger-driven-migration-validator
├── swagger-api-matching
├── nodejs-batch-api-validator
├── swagger-response-compare
├── api-authentication
├── api-client-retry-timeout
├── text-storage
└── report-generation
```

## Skills

| Skill | Use When |
|---|---|
| swagger-api-matching | Match old Swagger endpoints to new Swagger endpoints |
| nodejs-batch-api-validator | Generate Node.js CLI tool that validates APIs by batch params |
| swagger-response-compare | Compare old response with merged target response |
| api-authentication | Configure old/new API auth |
| api-client-retry-timeout | Add retry, timeout, and rate-limit behavior |
| text-storage | Persist TXT, CSV, JSONL, HTML reports |
| report-generation | Generate readable summary and report files |

## Golden Workflow

```text
load old-openapi.yaml
  ↓
load new-openapi.yaml
  ↓
match old operations to new operations
  ↓
write api-map.proposed.yaml
  ↓
human reviews and creates api-map.yaml
  ↓
load params.csv
  ↓
for each param row:
    call legacy API
    call target APIs
    merge target response
    compare mapped fields
    write report rows
  ↓
generate summary + report.html
```

## Main Prompt

```text
Read .copilot/skills/00-skill-index.md first.

Generate a Node.js TypeScript CLI tool named migval.

The tool should:
- parse old and new OpenAPI specs
- suggest API matches
- write api-map.proposed.yaml
- run batch validation using api-map.yaml and params.csv
- call old and target APIs
- merge split target responses
- compare fields
- write TXT, CSV, JSONL, and HTML reports
```
