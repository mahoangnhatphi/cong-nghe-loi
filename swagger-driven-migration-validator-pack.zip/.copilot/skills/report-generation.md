# Report Generation

## Purpose

Generate reports for Swagger-driven batch validation.

## Required Reports

```text
summary.txt
report.json
report.html
mismatches.csv
mismatches.jsonl
errors.jsonl
api-results.jsonl
```

## Summary Metrics

Include:

- run id
- status
- started time
- finished time
- total param rows
- passed rows
- failed rows
- old API call count
- new API call count
- API errors
- field mismatches
- top mismatched fields

## Mismatches CSV Columns

```text
run_id
api_match
param_key
param_json
field
legacy_path
target_path
legacy_value
target_value
type
status
reason
```

## HTML Report Sections

1. Run summary
2. API match summary
3. Param row pass/fail summary
4. Top mismatched fields
5. API errors
6. Sample mismatches
7. Links to CSV/JSONL files

## Assistant Behavior

- keep HTML readable
- write full detail to CSV/JSONL
- limit HTML examples
- include param values in mismatch rows
- group mismatches by API match and field
