# API Client Retry And Timeout

## Purpose

Add resilient API calling behavior for batch validation.

## Timeout Config

```yaml
timeouts:
  connect_seconds: 10
  request_seconds: 60
```

## Retry Config

```yaml
retry:
  enabled: true
  max_attempts: 3
  base_delay_ms: 500
  max_delay_ms: 10000
  jitter: true
  retry_status_codes:
    - 408
    - 429
    - 500
    - 502
    - 503
    - 504
```

## Retry Rules

Retry:

- 408
- 429
- 500
- 502
- 503
- 504

Do not retry by default:

- 400
- 401
- 403
- 404
- 422

## Rate Limit

```yaml
rate_limit:
  respect_retry_after: true
  max_retry_after_seconds: 120
```

## Batch Error Handling

```yaml
run:
  fail_fast: false
  continue_on_row_error: true
```

## Assistant Behavior

- centralize API request logic
- add retry with exponential backoff and jitter
- add timeout
- record status, duration, and attempts
- redact secrets
- write API errors to `errors.jsonl`
