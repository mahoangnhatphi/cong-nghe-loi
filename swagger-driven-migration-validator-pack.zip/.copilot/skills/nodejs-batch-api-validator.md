# Node.js Batch API Validator

## Purpose

Generate a Node.js TypeScript CLI tool that validates migration results by running old/new mapped APIs for rows in `params.csv`.

## Tool Name

```text
migval
```

## Runtime

Use:

- Node.js 20+
- TypeScript
- Commander
- YAML parser
- Axios or undici
- CSV parser
- JSONL writers
- HTML report generation

## Required Commands

### doctor

```bash
migval doctor --config config
```

Checks:

- config folder exists
- `api-map.yaml` exists
- `params.csv` exists
- auth env vars exist
- output folder writable
- OpenAPI files exist

### match-api

```bash
migval match-api   --old config/old-openapi.yaml   --new config/new-openapi.yaml   --out config/api-map.proposed.yaml
```

### run

```bash
migval run   --api-map config/api-map.yaml   --params config/params.csv
```

### report

```bash
migval report --run output/runs/latest
```

## Project Structure

```text
migval/
├── package.json
├── tsconfig.json
├── src/
│   ├── cli.ts
│   ├── commands/
│   │   ├── doctor.ts
│   │   ├── match-api.ts
│   │   ├── run.ts
│   │   └── report.ts
│   ├── openapi/
│   │   ├── load-openapi.ts
│   │   ├── extract-operations.ts
│   │   ├── operation-matcher.ts
│   │   └── api-map-writer.ts
│   ├── auth/
│   ├── api/
│   ├── validation/
│   ├── storage/
│   ├── report/
│   └── utils/
└── test/
```

## Suggested Dependencies

```json
{
  "dependencies": {
    "commander": "^12.0.0",
    "yaml": "^2.0.0",
    "axios": "^1.0.0",
    "zod": "^3.0.0",
    "csv-parse": "^5.0.0",
    "csv-stringify": "^6.0.0",
    "pino": "^9.0.0",
    "dayjs": "^1.11.0"
  },
  "devDependencies": {
    "typescript": "^5.0.0",
    "tsx": "^4.0.0",
    "vitest": "^1.0.0",
    "@types/node": "^20.0.0"
  }
}
```

## Batch Algorithm

```text
load api-map.yaml
load auth.yaml
load params.csv
create run folder

for each api_match:
  for each param row:
    build legacy request
    call legacy API
    extract legacy response_path

    for each target:
      build target request
      call target API
      extract target response_path
      merge into target object using merge_as

    compare legacy object and merged target object
    write mismatch/api/error rows

generate summary
generate HTML report
```

## Important Rules

- Keep OpenAPI parsing separate from runtime validation.
- Use `api-map.yaml` as the runtime contract.
- Use `params.csv` as batch input.
- Keep large responses local.
- Continue row execution on error unless `fail_fast` is true.
- Redact secrets from logs.
