# Swagger Response Compare

## Purpose

Compare a legacy API response with merged new API responses using configured field mappings.

## Example

Legacy response after `response_path: data`:

```json
{
  "employeeCode": "EMP001",
  "fullName": "Nguyen Van A",
  "salary": 1000
}
```

Merged target response:

```json
{
  "employee": { "code": "EMP001" },
  "profile": { "fullName": "Nguyen Van A" },
  "compensation": { "baseSalary": 1000 }
}
```

Field mappings:

```yaml
field_mappings:
  - legacy: employeeCode
    target: employee.code
    type: string

  - legacy: fullName
    target: profile.fullName
    type: string

  - legacy: salary
    target: compensation.baseSalary
    type: number
```

## Supported Types

- string
- number
- decimal
- boolean
- date
- datetime
- enum
- array
- object
- json

## Normalization

String:

```yaml
normalize:
  trim: true
  ignore_case: true
  collapse_spaces: true
```

Number:

```yaml
type: number
tolerance: 0.01
```

Date:

```yaml
type: date
legacy_format: yyyy-MM-dd
target_format: dd/MM/yyyy
canonical_format: yyyy-MM-dd
```

Enum:

```yaml
type: enum
enum_map:
  M: MALE
  Male: MALE
  Nam: MALE
  F: FEMALE
  Female: FEMALE
  Nữ: FEMALE
```

## Missing Field Behavior

Options:

- error
- warning
- ignore
- default

Example:

```yaml
on_missing_legacy: error
on_missing_target: error
```

## Derived Fields

Target from multiple fields:

```yaml
field_mappings:
  - legacy: fullName
    target:
      fields:
        - profile.firstName
        - profile.lastName
      transform: concat_space
    type: string
```

## Mismatch Output

```json
{
  "api_match": "employee_full_validation",
  "param": {"employeeId": "EMP001"},
  "field": "salary",
  "legacy_path": "salary",
  "target_path": "compensation.baseSalary",
  "legacy_value": 1000,
  "target_value": 999,
  "type": "number",
  "status": "mismatch",
  "reason": "difference exceeds tolerance"
}
```

## Assistant Behavior

- Do not compare raw JSON.
- Compare only configured field mappings.
- Include param row in mismatch report.
- Include raw values and paths.
- Apply normalization per mapping.
- Support missing field behavior.
