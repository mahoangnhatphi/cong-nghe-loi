# Swagger API Matching

## Purpose

Match old API operations to new API operations using Swagger/OpenAPI specs.

## Inputs

```text
config/old-openapi.yaml
config/new-openapi.yaml
```

## Output

```text
config/api-map.proposed.yaml
```

## Supported Match Types

### One To One

```text
old GET /api/employees/{employeeId}
  -> new GET /api/v2/employees/{employeeId}
```

### One To Many

```text
old GET /api/employee/full/{employeeId}
  -> new GET /api/v2/employees/{employeeId}
  -> new GET /api/v2/employees/{employeeId}/profile
  -> new GET /api/v2/employees/{employeeId}/salary
```

### Many To One

```text
old GET /api/employees/{employeeId}
old GET /api/profiles/{employeeId}
  -> new GET /api/v2/employee-summary/{employeeId}
```

## Signals To Use

Analyze:

- HTTP method
- path tokens
- path params
- query params
- operationId
- tags
- summary
- description
- request body schema
- response schema
- schema names
- response fields

## Confidence

Use 0 to 1 confidence.

```yaml
confidence:
  auto_accept_above: 0.95
  needs_review_above: 0.70
  reject_below: 0.50
```

Statuses:

- auto_accepted
- needs_review
- low_confidence
- rejected

Do not auto-accept uncertain one-to-many matches. That is how reports become fiction with timestamps.

## Param Binding

If old path uses:

```text
/api/employee/full/{employeeId}
```

and new path uses:

```text
/api/v2/employees/{empId}
```

then propose:

```yaml
param_binding:
  empId: employeeId
```

Meaning:

```text
API param -> params.csv column
```

## API Map Proposal Example

```yaml
api_matches:
  - name: employee_full_validation
    confidence: 0.94
    status: needs_review
    match_type: one_to_many
    reasons:
      - old endpoint returns full employee data
      - new endpoints split employee into basic, profile, salary
      - shared path parameter employeeId

    legacy:
      system: old
      operation_id: getEmployeeFull
      method: GET
      path: /api/employee/full/{employeeId}
      response_path: data

    targets:
      - system: new
        operation_id: getEmployeeBasic
        method: GET
        path: /api/v2/employees/{employeeId}
        response_path: data.employee
        merge_as: employee

      - system: new
        operation_id: getEmployeeProfile
        method: GET
        path: /api/v2/employees/{employeeId}/profile
        response_path: data.profile
        merge_as: profile

    param_binding:
      employeeId: employeeId

    field_mappings: []
```

## Assistant Behavior

When invoked:

1. Parse old and new OpenAPI specs.
2. Extract operations.
3. Score operation candidates.
4. Propose one-to-one and one-to-many matches.
5. Generate `api-map.proposed.yaml`.
6. Mark uncertain matches as `needs_review`.
7. Include reasons.
8. Include param bindings.
9. Include response path placeholders.
