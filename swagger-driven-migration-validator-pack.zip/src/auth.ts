import { AuthConfig } from './types.js';

export function validateAuthConfig(config: AuthConfig): string[] {
  const missing: string[] = [];
  for (const [profileName, profile] of Object.entries(config.auth_profiles ?? {})) {
    if (profile.type === 'bearer') {
      if (!profile.token_env) {
        missing.push(`auth_profiles.${profileName}.token_env`);
      } else if (!process.env[profile.token_env]) {
        missing.push(profile.token_env);
      }
    }
    if (profile.type === 'api_key') {
      if (profile.value_env && !process.env[profile.value_env]) {
        missing.push(profile.value_env);
      }
    }
    if (profile.type === 'basic') {
      if (!profile.username_env) {
        missing.push(`auth_profiles.${profileName}.username_env`);
      }
      if (!profile.password_env) {
        missing.push(`auth_profiles.${profileName}.password_env`);
      }
      if (profile.username_env && !process.env[profile.username_env]) {
        missing.push(profile.username_env);
      }
      if (profile.password_env && !process.env[profile.password_env]) {
        missing.push(profile.password_env);
      }
    }
    if (profile.type === 'custom_headers') {
      const headers = profile.headers ?? {};
      for (const headerValue of Object.values(headers)) {
        if (headerValue.env && !process.env[headerValue.env]) {
          missing.push(headerValue.env);
        }
      }
    }
  }
  for (const [systemName, system] of Object.entries(config.systems ?? {})) {
    if (!system.base_url) {
      missing.push(`systems.${systemName}.base_url`);
    }
    if (!system.auth_ref) {
      missing.push(`systems.${systemName}.auth_ref`);
    }
  }
  return missing;
}

export function buildAuthHeaders(system: string, config: AuthConfig): Record<string, string> {
  const systemConfig = config.systems?.[system];
  if (!systemConfig) return {};
  const profile = config.auth_profiles?.[systemConfig.auth_ref];
  if (!profile) return {};

  switch (profile.type) {
    case 'bearer': {
      const token = process.env[profile.token_env ?? ''] ?? '';
      if (!token) return {};
      return { Authorization: `Bearer ${token}` };
    }
    case 'api_key': {
      const value = profile.value_env ? process.env[profile.value_env] : undefined;
      if (!profile.name || !value) return {};
      if (profile.in === 'query') {
        return { 'X-MigVal-Api-Key': value };
      }
      return { [profile.name]: value };
    }
    case 'basic': {
      const username = process.env[profile.username_env ?? ''] ?? '';
      const password = process.env[profile.password_env ?? ''] ?? '';
      if (!username || !password) return {};
      const token = Buffer.from(`${username}:${password}`).toString('base64');
      return { Authorization: `Basic ${token}` };
    }
    case 'custom_headers': {
      const headers: Record<string, string> = {};
      for (const [headerName, headerValue] of Object.entries(profile.headers ?? {})) {
        if (headerValue.env) {
          const value = process.env[headerValue.env];
          if (value) {
            headers[headerName] = value;
          }
        } else if (headerValue.value) {
          headers[headerName] = headerValue.value;
        }
      }
      return headers;
    }
  }
  return {};
}

export function getSystemBaseUrl(system: string, config: AuthConfig): string | undefined {
  return config.systems?.[system]?.base_url;
}

export function redactHeaders(headers: Record<string, string>): Record<string, string> {
  const redacted: Record<string, string> = {};
  for (const [name, value] of Object.entries(headers)) {
    if (/authorization|token|key|secret/i.test(name)) {
      redacted[name] = value ? 'REDACTED' : '';
    } else {
      redacted[name] = value;
    }
  }
  return redacted;
}
