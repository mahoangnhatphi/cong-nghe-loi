export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD' | 'OPTIONS';

export interface ApiMatchConfig {
  api_matches: ApiMatch[];
}

export interface ApiMatch {
  name: string;
  confidence?: number;
  status?: 'auto_accepted' | 'needs_review' | 'low_confidence' | 'rejected';
  match_type: 'one_to_one' | 'one_to_many' | 'many_to_one';
  reasons?: string[];
  legacy: OperationRef;
  targets: OperationRef[];
  param_binding?: Record<string, string>;
  run?: {
    fail_fast?: boolean;
    continue_on_row_error?: boolean;
  };
  field_mappings?: FieldMapping[];
}

export interface OperationRef {
  system: string;
  operation_id?: string;
  method: HttpMethod;
  path: string;
  response_path?: string;
  merge_as?: string;
}

export interface FieldMapping {
  legacy: string;
  target: string;
  type: 'string' | 'number' | 'date' | 'enum' | 'boolean' | 'auto';
  normalize?: {
    trim?: boolean;
    ignore_case?: boolean;
    collapse_spaces?: boolean;
  };
  legacy_format?: string;
  target_format?: string;
  tolerance?: number;
  enum_map?: Record<string, string>;
}

export interface AuthConfig {
  auth_profiles: Record<string, AuthProfile>;
  systems: Record<string, AuthSystem>;
}

export interface AuthProfile {
  type: 'bearer' | 'api_key' | 'basic' | 'custom_headers';
  token_env?: string;
  username_env?: string;
  password_env?: string;
  value_env?: string;
  in?: 'header' | 'query';
  name?: string;
  headers?: Record<string, AuthHeaderValue>;
}

export interface AuthHeaderValue {
  value?: string;
  env?: string;
}

export interface AuthSystem {
  base_url: string;
  auth_ref: string;
}

export interface OpenApiOperation {
  system: string;
  operationId: string;
  method: HttpMethod;
  path: string;
  summary?: string;
  description?: string;
  parameterNames: string[];
}

export interface RunParams {
  [column: string]: string;
}

export interface RunSummary {
  run_id: string;
  status: 'completed' | 'failed';
  started_at: string;
  finished_at: string;
  total_rows: number;
  passed_rows: number;
  failed_rows: number;
  old_api_calls: number;
  new_api_calls: number;
  errors: number;
  mismatches: number;
}

export interface MismatchRow {
  run_id: string;
  api_match: string;
  row_index: number;
  param_json: string;
  field: string;
  legacy_path: string;
  target_path: string;
  legacy_value: string;
  target_value: string;
  type: string;
  status: 'mismatch';
  reason: string;
}

export interface ErrorRow {
  run_id: string;
  api_match: string;
  row_index: number;
  param_json: string;
  error: string;
}
