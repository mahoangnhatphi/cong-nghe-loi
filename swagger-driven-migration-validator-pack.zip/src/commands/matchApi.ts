import { Command } from 'commander';
import path from 'path';
import { saveYaml } from '../utils.js';
import { proposeApiMap } from '../openapi.js';

export const matchApiCommand = new Command('match-api')
  .description('Propose API mapping from old and new OpenAPI specs')
  .requiredOption('--old <file>', 'old OpenAPI spec file')
  .requiredOption('--new <file>', 'new OpenAPI spec file')
  .requiredOption('--out <file>', 'output proposed api map yaml file')
  .action(async (options) => {
    const oldPath = path.resolve(options.old);
    const newPath = path.resolve(options.new);
    const outPath = path.resolve(options.out);
    const proposal = await proposeApiMap(oldPath, newPath);
    await saveYaml(outPath, proposal);
    console.log(`API map proposal saved to ${outPath}`);
  });
