import { Command } from 'commander';
import fs from 'fs/promises';
import path from 'path';
import { loadYaml } from '../utils.js';
import { validateAuthConfig } from '../auth.js';
import { AuthConfig } from '../types.js';

export const doctorCommand = new Command('doctor')
  .description('Validate required config files and auth settings')
  .requiredOption('--config <folder>', 'config folder path')
  .action(async (options) => {
    const configPath = path.resolve(options.config);
    const errors: string[] = [];

    try {
      await fs.access(configPath);
    } catch {
      console.error(`Config folder not found: ${configPath}`);
      process.exit(1);
    }

    const requiredFiles = ['api-map.yaml', 'params.csv', 'auth.yaml', 'old-openapi.yaml', 'new-openapi.yaml'];
    for (const fileName of requiredFiles) {
      try {
        await fs.access(path.join(configPath, fileName));
      } catch {
        errors.push(`Missing ${fileName}`);
      }
    }

    if (errors.length === 0) {
      try {
        const authConfig = await loadYaml<AuthConfig>(path.join(configPath, 'auth.yaml'));
        const missingEnv = validateAuthConfig(authConfig);
        if (missingEnv.length) {
          errors.push(`Missing authentication environment values: ${missingEnv.join(', ')}`);
        }
      } catch (error) {
        errors.push(`Unable to read auth.yaml: ${error instanceof Error ? error.message : String(error)}`);
      }
    }

    if (errors.length) {
      console.error('Doctor found configuration issues:');
      for (const issue of errors) {
        console.error(`  - ${issue}`);
      }
      process.exit(1);
    }

    console.log('Doctor check passed. All required config files exist and auth settings are validated.');
  });
