import { Command } from 'commander';
import path from 'path';
import { generateReport } from '../report.js';

export const reportCommand = new Command('report')
  .description('Generate HTML report from a completed run')
  .requiredOption('--run <folder>', 'run output folder path')
  .action(async (options) => {
    const runDir = path.resolve(options.run);
    await generateReport(runDir);
    console.log(`Report generated at ${path.join(runDir, 'report.html')}`);
  });
