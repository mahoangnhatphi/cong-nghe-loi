import { Command } from 'commander';
import path from 'path';
import { loadYaml, loadCsvRows } from '../utils.js';
import { runValidation } from '../validator.js';
import { AuthConfig, ApiMatchConfig } from '../types.js';

export const runCommand = new Command('run')
  .description('Execute validation using api-map and params')
  .requiredOption('--api-map <file>', 'api map YAML file')
  .requiredOption('--params <file>', 'params CSV file')
  .option('--config <folder>', 'config folder path for auth.yaml')
  .option('--output <folder>', 'output run folder', 'output/runs')
  .action(async (options) => {
    const apiMapPath = path.resolve(options.apiMap);
    const paramsPath = path.resolve(options.params);
    const configDir = options.config ? path.resolve(options.config) : path.dirname(apiMapPath);
    const authPath = path.join(configDir, 'auth.yaml');
    const outputDir = path.resolve(options.output);

    const apiMap = await loadYaml<ApiMatchConfig>(apiMapPath);
    const authConfig = await loadYaml<AuthConfig>(authPath);
    const params = await loadCsvRows(paramsPath);

    const summary = await runValidation(apiMap, authConfig, params, outputDir);
    console.log(`Run complete. Summary written to ${outputDir}/${summary.run_id}/summary.json`);
  });
