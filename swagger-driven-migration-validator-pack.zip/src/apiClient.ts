import axios, { AxiosRequestConfig } from 'axios';
import { buildAuthHeaders, getSystemBaseUrl } from './auth.js';
import { AuthConfig, RunParams } from './types.js';
import { replacePathParams } from './utils.js';

export interface ApiRequest {
  url: string;
  method: string;
  headers: Record<string, string>;
  body?: unknown;
}

export async function buildRequest(system: string, pathTemplate: string, method: string, params: RunParams, authConfig: AuthConfig): Promise<ApiRequest> {
  const baseUrl = getSystemBaseUrl(system, authConfig);
  if (!baseUrl) {
    throw new Error(`Missing base_url for system ${system}`);
  }
  const url = `${baseUrl.replace(/\/$/, '')}${replacePathParams(pathTemplate, params)}`;
  const headers = buildAuthHeaders(system, authConfig);
  return { url, method, headers };
}

export async function executeRequest(request: ApiRequest): Promise<{ status: number; duration: number; data: unknown }> {
  const config: AxiosRequestConfig = {
    url: request.url,
    method: request.method as AxiosRequestConfig['method'],
    headers: request.headers,
    timeout: 30000,
    validateStatus: () => true,
  };
  const started = Date.now();
  const response = await axios.request(config);
  const duration = Date.now() - started;
  let data: unknown = response.data;
  if (typeof data === 'string') {
    try {
      data = JSON.parse(data);
    } catch {
      data = response.data;
    }
  }
  return { status: response.status, duration, data };
}
