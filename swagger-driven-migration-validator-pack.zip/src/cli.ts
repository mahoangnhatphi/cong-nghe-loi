#!/usr/bin/env node
import { Command } from 'commander';
import { doctorCommand } from './commands/doctor.js';
import { matchApiCommand } from './commands/matchApi.js';
import { runCommand } from './commands/run.js';
import { reportCommand } from './commands/report.js';

const program = new Command();
program.name('migval').description('Swagger-driven migration validation CLI').version('0.1.0');

program.addCommand(doctorCommand);
program.addCommand(matchApiCommand);
program.addCommand(runCommand);
program.addCommand(reportCommand);

program.parse(process.argv);
