import fs from 'fs/promises';
import path from 'path';
import { parse } from 'csv-parse/sync';
import YAML from 'yaml';
import { RunParams } from './types.js';

export async function loadYaml<T = unknown>(filePath: string): Promise<T> {
  const content = await fs.readFile(filePath, 'utf8');
  return YAML.parse(content) as T;
}

export async function saveYaml(filePath: string, data: unknown): Promise<void> {
  const content = YAML.stringify(data);
  await ensureDir(path.dirname(filePath));
  await fs.writeFile(filePath, content, 'utf8');
}

export async function loadJson<T = unknown>(filePath: string): Promise<T> {
  const text = await fs.readFile(filePath, 'utf8');
  return JSON.parse(text) as T;
}

export async function loadJsonl<T = unknown>(filePath: string): Promise<T[]> {
  const text = await fs.readFile(filePath, 'utf8');
  return text
    .split(/\r?\n/)
    .filter((line) => line.trim().length > 0)
    .map((line) => JSON.parse(line) as T);
}

export async function saveJson(filePath: string, data: unknown): Promise<void> {
  await ensureDir(path.dirname(filePath));
  await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf8');
}

export async function saveJsonl(filePath: string, data: unknown[]): Promise<void> {
  await ensureDir(path.dirname(filePath));
  const lines = data.map((item) => JSON.stringify(item));
  await fs.writeFile(filePath, lines.join('\n') + (lines.length ? '\n' : ''), 'utf8');
}

export async function loadCsvRows(filePath: string): Promise<RunParams[]> {
  const content = await fs.readFile(filePath, 'utf8');
  const records = parse(content, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
  });
  return records as RunParams[];
}

export async function ensureDir(dirPath: string): Promise<void> {
  await fs.mkdir(dirPath, { recursive: true });
}

export function joinPath(...segments: string[]): string {
  return path.join(...segments);
}

export function extractPathValue(root: unknown, responsePath?: string): unknown {
  if (responsePath == null || responsePath.trim() === '') {
    return root;
  }
  const parts = responsePath.split('.').filter(Boolean);
  let current: any = root;
  for (const part of parts) {
    if (current == null) {
      return undefined;
    }
    current = current[part];
  }
  return current;
}

export function getObjectPath(root: unknown, pathString: string): unknown {
  if (pathString.trim() === '') {
    return root;
  }
  const segments = pathString.split('.').filter(Boolean);
  let current: any = root;
  for (const segment of segments) {
    if (current == null) {
      return undefined;
    }
    current = current[segment];
  }
  return current;
}

export function stringifyValue(value: unknown): string {
  if (value == null) return '';
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

export function normalizeString(value: unknown, normalize?: { trim?: boolean; ignore_case?: boolean; collapse_spaces?: boolean; }): string {
  let result = stringifyValue(value);
  if (normalize?.trim) {
    result = result.trim();
  }
  if (normalize?.collapse_spaces) {
    result = result.replace(/\s+/g, ' ');
  }
  if (normalize?.ignore_case) {
    result = result.toLowerCase();
  }
  return result;
}

export function compareValues(left: unknown, right: unknown, mapping: { type: string; normalize?: { trim?: boolean; ignore_case?: boolean; collapse_spaces?: boolean }; tolerance?: number; enum_map?: Record<string, string> | undefined; legacy_format?: string; target_format?: string; }): { pass: boolean; reason?: string } {
  const type = mapping.type ?? 'auto';
  if (left == null && right == null) {
    return { pass: true };
  }

  if (type === 'number' || (type === 'auto' && typeof left === 'number' && typeof right === 'number')) {
    const leftNum = Number(left);
    const rightNum = Number(right);
    if (Number.isNaN(leftNum) || Number.isNaN(rightNum)) {
      return { pass: false, reason: 'number_parse_failed' };
    }
    const tolerance = mapping.tolerance ?? 0;
    if (Math.abs(leftNum - rightNum) <= tolerance) {
      return { pass: true };
    }
    return { pass: false, reason: `tolerance_exceeded_${Math.abs(leftNum - rightNum)}` };
  }

  if (type === 'enum') {
    let leftNorm = stringifyValue(left);
    let rightNorm = stringifyValue(right);
    if (mapping.enum_map) {
      leftNorm = mapping.enum_map[leftNorm] ?? leftNorm;
      rightNorm = mapping.enum_map[rightNorm] ?? rightNorm;
    }
    if (leftNorm === rightNorm) {
      return { pass: true };
    }
    return { pass: false, reason: 'enum_mismatch' };
  }

  if (type === 'boolean' || (type === 'auto' && typeof left === 'boolean' && typeof right === 'boolean')) {
    return { pass: left === right, reason: left === right ? undefined : 'boolean_mismatch' };
  }

  const leftString = normalizeString(left, mapping.normalize);
  const rightString = normalizeString(right, mapping.normalize);
  if (leftString === rightString) {
    return { pass: true };
  }
  return { pass: false, reason: 'string_mismatch' };
}

export function replacePathParams(pathTemplate: string, values: Record<string, string>): string {
  return pathTemplate.replace(/\{([^}]+)\}/g, (_, name) => {
    const replacement = values[name];
    if (replacement == null) {
      return `{${name}}`;
    }
    return encodeURIComponent(replacement);
  });
}

export function toCsv(rows: unknown[]): string {
  if (rows.length === 0) return '';
  const first = rows[0] as Record<string, unknown>;
  const columns = Object.keys(first);
  const header = columns.join(',');
  const lines = [header];
  for (const row of rows) {
    const objectRow = row as Record<string, unknown>;
    const values = columns.map((col) => {
      const raw = objectRow[col];
      const value = raw == null ? '' : String(raw);
      if (value.includes(',') || value.includes('"') || value.includes('\n')) {
        return `"${value.replace(/"/g, '""')}"`;
      }
      return value;
    });
    lines.push(values.join(','));
  }
  return lines.join('\n');
}
