import fs from 'fs/promises';
import { ApiMatchConfig, MismatchRow, RunParams, RunSummary } from './types.js';
import { ApiRequest, buildRequest, executeRequest } from './apiClient.js';
import { extractPathValue, getObjectPath, compareValues, stringifyValue, saveJson, saveJsonl, ensureDir, joinPath, toCsv } from './utils.js';
import { AuthConfig } from './types.js';

export async function runValidation(apiMap: ApiMatchConfig, authConfig: AuthConfig, params: RunParams[], outputDir: string): Promise<RunSummary> {
  await ensureDir(outputDir);
  const runId = `run-${Date.now()}`;
  const runDir = joinPath(outputDir, runId);
  const latestDir = joinPath(outputDir, 'latest');
  await ensureDir(runDir);
  await ensureDir(latestDir);

  const mismatches: MismatchRow[] = [];
  const errors: unknown[] = [];
  const apiResults: unknown[] = [];

  let oldApiCalls = 0;
  let newApiCalls = 0;
  let passedRows = 0;
  let failedRows = 0;

  for (let rowIndex = 0; rowIndex < params.length; rowIndex += 1) {
    const row = params[rowIndex];
    let rowPassed = true;

    for (const match of apiMap.api_matches ?? []) {
      try {
        const requestParams = buildParamsForOperation(row, match.param_binding ?? {});
        const legacyRequest = await buildRequest(match.legacy.system, match.legacy.path, match.legacy.method, requestParams, authConfig);
        const legacyResponse = await executeRequest(legacyRequest);
        oldApiCalls += 1;
        apiResults.push(buildResultRow(match.name, rowIndex, match.legacy.system, legacyRequest, legacyResponse, runId));

        if (legacyResponse.status >= 400) {
          throw new Error(`legacy call failed with status ${legacyResponse.status}`);
        }

        const legacyData = extractPathValue(legacyResponse.data, match.legacy.response_path);
        const mergedTarget: Record<string, unknown> = {};

        for (const target of match.targets ?? []) {
          const targetRequest = await buildRequest(target.system, target.path, target.method, requestParams, authConfig);
          const targetResponse = await executeRequest(targetRequest);
          newApiCalls += 1;
          apiResults.push(buildResultRow(match.name, rowIndex, target.system, targetRequest, targetResponse, runId));

          if (targetResponse.status >= 400) {
            throw new Error(`target ${target.system} call failed with status ${targetResponse.status}`);
          }

          const fragment = extractPathValue(targetResponse.data, target.response_path);
          if (target.merge_as) {
            mergedTarget[target.merge_as] = fragment;
          } else if (match.targets.length === 1 && fragment && typeof fragment === 'object') {
            Object.assign(mergedTarget, fragment as Record<string, unknown>);
          }
        }

        for (const mapping of match.field_mappings ?? []) {
          const legacyValue = getObjectPath(legacyData, mapping.legacy);
          const targetValue = getObjectPath(mergedTarget, mapping.target);
          const comparison = compareValues(legacyValue, targetValue, {
            type: mapping.type,
            normalize: mapping.normalize,
            tolerance: mapping.tolerance,
            enum_map: mapping.enum_map,
            legacy_format: mapping.legacy_format,
            target_format: mapping.target_format,
          });
          if (!comparison.pass) {
            rowPassed = false;
            mismatches.push({
              run_id: runId,
              api_match: match.name,
              row_index: rowIndex,
              param_json: JSON.stringify(row),
              field: mapping.legacy,
              legacy_path: mapping.legacy,
              target_path: mapping.target,
              legacy_value: stringifyValue(legacyValue),
              target_value: stringifyValue(targetValue),
              type: mapping.type,
              status: 'mismatch',
              reason: comparison.reason ?? 'values_differ',
            });
          }
        }
      } catch (error) {
        rowPassed = false;
        errors.push({
          run_id: runId,
          api_match: match.name,
          row_index: rowIndex,
          param_json: JSON.stringify(row),
          error: error instanceof Error ? error.message : String(error),
        });
        if (match.run?.fail_fast) {
          break;
        }
      }
    }

    if (rowPassed) {
      passedRows += 1;
    } else {
      failedRows += 1;
    }
  }

  const summary: RunSummary = {
    run_id: runId,
    status: 'completed',
    started_at: new Date().toISOString(),
    finished_at: new Date().toISOString(),
    total_rows: params.length,
    passed_rows: passedRows,
    failed_rows: failedRows,
    old_api_calls: oldApiCalls,
    new_api_calls: newApiCalls,
    errors: errors.length,
    mismatches: mismatches.length,
  };

  await saveJson(joinPath(runDir, 'summary.json'), summary);
  await saveJson(joinPath(latestDir, 'summary.json'), summary);
  await saveJsonl(joinPath(runDir, 'api-results.jsonl'), apiResults);
  await saveJsonl(joinPath(latestDir, 'api-results.jsonl'), apiResults);
  await saveJsonl(joinPath(runDir, 'errors.jsonl'), errors);
  await saveJsonl(joinPath(latestDir, 'errors.jsonl'), errors);
  await saveJsonl(joinPath(runDir, 'mismatches.jsonl'), mismatches);
  await saveJsonl(joinPath(latestDir, 'mismatches.jsonl'), mismatches);
  await fs.writeFile(joinPath(runDir, 'mismatches.csv'), toCsv(mismatches), 'utf8');
  await fs.writeFile(joinPath(latestDir, 'mismatches.csv'), toCsv(mismatches), 'utf8');
  await fs.writeFile(joinPath(runDir, 'errors.csv'), toCsv(errors as Record<string, unknown>[]), 'utf8');
  await fs.writeFile(joinPath(latestDir, 'errors.csv'), toCsv(errors as Record<string, unknown>[]), 'utf8');

  return summary;
}

function buildResultRow(matchName: string, rowIndex: number, system: string, request: ApiRequest, response: { status: number; duration: number; data: unknown }, runId: string): unknown {
  return {
    run_id: runId,
    api_match: matchName,
    row_index: rowIndex,
    system,
    url: request.url,
    method: request.method,
    status: response.status,
    duration_ms: response.duration,
  };
}

function buildParamsForOperation(row: RunParams, binding: Record<string, string>): RunParams {
  const params: RunParams = {};
  for (const [paramName, csvColumn] of Object.entries(binding)) {
    if (csvColumn in row) {
      params[paramName] = row[csvColumn];
    }
  }
  for (const [column, value] of Object.entries(row)) {
    if (!(column in params)) {
      params[column] = value;
    }
  }
  return params;
}
