import fs from 'fs/promises';
import YAML from 'yaml';
import { HttpMethod, OpenApiOperation } from './types.js';

interface OpenApiDocument {
  paths?: Record<string, Record<string, any>>;
}

export async function loadOpenApiSpec(filePath: string): Promise<OpenApiDocument> {
  const content = await fs.readFile(filePath, 'utf8');
  return YAML.parse(content) as OpenApiDocument;
}

export function extractOperations(spec: OpenApiDocument, system: string): OpenApiOperation[] {
  const ops: OpenApiOperation[] = [];
  const paths = spec.paths ?? {};
  for (const [pathKey, methods] of Object.entries(paths)) {
    for (const [methodRaw, operation] of Object.entries(methods ?? {})) {
      const method = methodRaw.toUpperCase() as HttpMethod;
      if (!method || typeof operation !== 'object') continue;
      const operationId = operation.operationId ?? `${method}:${pathKey}`;
      const summary = operation.summary ?? operation.description ?? '';
      const parameterNames = Array.isArray(operation.parameters)
        ? operation.parameters.map((param: any) => param.name).filter(Boolean)
        : [];
      ops.push({ system, operationId, method, path: pathKey, summary, description: operation.description, parameterNames });
    }
  }
  return ops;
}

function normalizePath(pathString: string): string {
  return pathString
    .replace(/\{[^}]+\}/g, '{param}')
    .replace(/\/+/g, '/')
    .replace(/\/$/, '')
    .toLowerCase();
}

function scorePaths(oldPath: string, newPath: string): number {
  const a = normalizePath(oldPath).split('/').filter(Boolean);
  const b = normalizePath(newPath).split('/').filter(Boolean);
  if (a.length === 0 || b.length === 0) return 0;
  const shared = a.filter((token) => b.includes(token)).length;
  return shared / Math.max(a.length, b.length);
}

function scoreText(a: string, b: string): number {
  if (!a || !b) return 0;
  const aWords = new Set(a.toLowerCase().split(/\W+/).filter(Boolean));
  const bWords = new Set(b.toLowerCase().split(/\W+/).filter(Boolean));
  if (!aWords.size || !bWords.size) return 0;
  let overlap = 0;
  for (const word of aWords) {
    if (bWords.has(word)) overlap += 1;
  }
  return overlap / Math.max(aWords.size, bWords.size);
}

function computeMatchScore(oldOp: OpenApiOperation, newOp: OpenApiOperation): number {
  const methodMatch = oldOp.method === newOp.method ? 1 : 0;
  const pathScore = scorePaths(oldOp.path, newOp.path);
  const idScore = oldOp.operationId && newOp.operationId && oldOp.operationId.toLowerCase() === newOp.operationId.toLowerCase() ? 0.2 : 0;
  const summaryScore = scoreText(oldOp.summary ?? '', newOp.summary ?? '');
  return Math.min(1, methodMatch * 0.6 + pathScore * 0.3 + idScore + summaryScore * 0.1);
}

function getParamNames(pathString: string): string[] {
  const matches = Array.from(pathString.matchAll(/\{([^}]+)\}/g));
  return matches.map((m) => m[1]);
}

function buildParamBinding(oldPath: string, newPath: string): Record<string, string> {
  const oldParams = getParamNames(oldPath);
  const newParams = getParamNames(newPath);
  const mapping: Record<string, string> = {};
  for (let i = 0; i < Math.min(oldParams.length, newParams.length); i += 1) {
    mapping[newParams[i]] = oldParams[i];
  }
  for (const common of oldParams) {
    if (newParams.includes(common)) {
      mapping[common] = common;
    }
  }
  return mapping;
}

function chooseMergeName(target: OpenApiOperation, index: number): string {
  if (target.operationId) {
    return target.operationId.replace(/^(get|fetch|retrieve)/i, '').replace(/[^a-zA-Z0-9]+/g, '_').replace(/^_+|_+$/g, '') || `target_${index}`;
  }
  const segments = target.path.split('/').filter(Boolean);
  return segments.length ? segments[segments.length - 1].replace(/[^a-zA-Z0-9]+/g, '_') : `target_${index}`;
}

export async function proposeApiMap(oldSpecPath: string, newSpecPath: string): Promise<Record<string, unknown>> {
  const [oldSpec, newSpec] = await Promise.all([loadOpenApiSpec(oldSpecPath), loadOpenApiSpec(newSpecPath)]);
  const oldOps = extractOperations(oldSpec, 'old');
  const newOps = extractOperations(newSpec, 'new');
  const api_matches: unknown[] = [];

  for (const oldOp of oldOps) {
    const candidates = newOps.map((newOp) => ({ newOp, score: computeMatchScore(oldOp, newOp) }));
    candidates.sort((a, b) => b.score - a.score);
    const best = candidates[0];
    if (!best || best.score < 0.2) continue;
    const status = best.score >= 0.95 ? 'auto_accepted' : 'needs_review';
    const matchType: 'one_to_one' = 'one_to_one';
    const param_binding = buildParamBinding(oldOp.path, best.newOp.path);
    api_matches.push({
      name: `${oldOp.operationId.replace(/[^a-zA-Z0-9]+/g, '_')}_to_${best.newOp.operationId.replace(/[^a-zA-Z0-9]+/g, '_')}`,
      confidence: Number(best.score.toFixed(2)),
      status,
      match_type: matchType,
      reasons: [
        `Matched old ${oldOp.method} ${oldOp.path} to new ${best.newOp.method} ${best.newOp.path}`,
        `Path similarity ${scorePaths(oldOp.path, best.newOp.path).toFixed(2)}`,
      ],
      legacy: {
        system: 'old',
        operation_id: oldOp.operationId,
        method: oldOp.method,
        path: oldOp.path,
        response_path: 'data',
      },
      targets: [
        {
          system: 'new',
          operation_id: best.newOp.operationId,
          method: best.newOp.method,
          path: best.newOp.path,
          response_path: 'data',
          merge_as: chooseMergeName(best.newOp, 1),
        },
      ],
      param_binding,
      field_mappings: [],
    });
  }
  return { api_matches };
}
