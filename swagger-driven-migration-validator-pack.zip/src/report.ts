import { loadJson, loadJsonl, saveJson, ensureDir, joinPath } from './utils.js';
import { RunSummary, MismatchRow } from './types.js';

export async function generateReport(runDir: string): Promise<void> {
  const summary = await loadJson<RunSummary>(joinPath(runDir, 'summary.json'));
  const mismatches = await loadJsonl<MismatchRow>(joinPath(runDir, 'mismatches.jsonl'));
  const sections = [];

  sections.push(`<h1>Migration Validation Report</h1>`);
  sections.push(`<p>Run ID: ${summary.run_id}</p>`);
  sections.push(`<p>Status: ${summary.status}</p>`);
  sections.push(`<p>Started: ${summary.started_at}</p>`);
  sections.push(`<p>Finished: ${summary.finished_at}</p>`);
  sections.push(`<p>Total rows: ${summary.total_rows}</p>`);
  sections.push(`<p>Passed rows: ${summary.passed_rows}</p>`);
  sections.push(`<p>Failed rows: ${summary.failed_rows}</p>`);
  sections.push(`<p>Old API calls: ${summary.old_api_calls}</p>`);
  sections.push(`<p>New API calls: ${summary.new_api_calls}</p>`);
  sections.push(`<p>Mismatches: ${summary.mismatches}</p>`);
  sections.push(`<p>Errors: ${summary.errors}</p>`);

  if (mismatches.length) {
    sections.push('<h2>Top mismatches</h2>');
    const subset = mismatches.slice(0, 20);
    sections.push('<table border="1" cellpadding="6" cellspacing="0">');
    sections.push('<thead><tr><th>api_match</th><th>row</th><th>field</th><th>legacy</th><th>target</th><th>reason</th></tr></thead>');
    sections.push('<tbody>');
    for (const mismatch of subset) {
      sections.push(`<tr><td>${escapeHtml(mismatch.api_match)}</td><td>${mismatch.row_index}</td><td>${escapeHtml(mismatch.field)}</td><td>${escapeHtml(mismatch.legacy_value)}</td><td>${escapeHtml(mismatch.target_value)}</td><td>${escapeHtml(mismatch.reason)}</td></tr>`);
    }
    sections.push('</tbody></table>');
  } else {
    sections.push('<p>No mismatches detected.</p>');
  }

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<title>Migration Validation Report</title>
<style>body{font-family:Arial,Helvetica,sans-serif;line-height:1.5}table{border-collapse:collapse;width:100%}th,td{padding:8px;text-align:left}th{background:#f2f2f2}</style>
</head>
<body>
${sections.join('\n')}
</body>
</html>`;

  await ensureDir(runDir);
  await saveJson(joinPath(runDir, 'report.json'), summary);
  await fsWriteFile(joinPath(runDir, 'report.html'), html, 'utf8');
}

function escapeHtml(value: string): string {
  return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

async function fsWriteFile(filePath: string, content: string, encoding: BufferEncoding) {
  await import('fs/promises').then((fs) => fs.writeFile(filePath, content, { encoding }));
}
