# Swagger-Driven Migration Validator Pack

Use this pack when you already have Swagger/OpenAPI specs for old and new APIs.

## Main Workflow

```text
Old OpenAPI + New OpenAPI
        ↓
API matching
        ↓
config/api-map.yaml
        ↓
Node.js batch validator
        ↓
Run validation for rows in config/params.csv
        ↓
TXT / CSV / JSONL / HTML reports
```

## Why This Pack Exists

The old API may return full data, while the new APIs may split the same data into multiple endpoints.

Instead of pasting huge JSON responses into Copilot, use OpenAPI contracts to:

- match old API to new API/API group
- bind params from CSV
- call APIs locally
- merge target responses
- compare mapped fields
- write reports locally

Big payloads stay on disk, where they belong. Not in chat, because apparently token bonfires are frowned upon.

## Folder Structure

```text
.github/
├── copilot-instructions.md
└── prompts/
    ├── generate-swagger-driven-validator.prompt.md
    ├── generate-api-map.prompt.md
    ├── review-api-map.prompt.md
    └── generate-nodejs-tool.prompt.md

.copilot/
└── skills/
    ├── 00-skill-index.md
    ├── swagger-api-matching.md
    ├── nodejs-batch-api-validator.md
    ├── swagger-response-compare.md
    ├── api-authentication.md
    ├── api-client-retry-timeout.md
    ├── text-storage.md
    └── report-generation.md

config/
├── old-openapi.yaml
├── new-openapi.yaml
├── auth.yaml
├── api-map.yaml
├── api-map.proposed.yaml
├── params.csv
├── comparison.yaml
├── storage.yaml
└── report.yaml

docs/
├── workflow.md
├── api-map-format.md
└── command-examples.md
```

## How To Use

Copy this pack into your project root.

Then ask Copilot:

```text
Read .copilot/skills/00-skill-index.md first.
Then read all related skills under .copilot/skills.

I already have old and new Swagger/OpenAPI specs.

Generate a Node.js 20 TypeScript CLI tool named migval that:
- parses old and new OpenAPI specs
- suggests API matches
- writes config/api-map.proposed.yaml
- runs batch validation using config/api-map.yaml and config/params.csv
- supports auth
- calls old and new APIs
- merges split target API responses
- compares fields using field_mappings
- writes TXT, CSV, JSONL, and HTML reports
```

Expected commands after Copilot generates the tool:

```bash
migval doctor --config config
migval match-api --old config/old-openapi.yaml --new config/new-openapi.yaml --out config/api-map.proposed.yaml
migval run --api-map config/api-map.yaml --params config/params.csv
migval report --run output/runs/latest
```

```bash
npm install
npm run build
node dist/cli.js doctor --config config
npx tsx src/cli.ts match-api --old config/old-openapi.yaml --new config/new-openapi.yaml --out config/api-map.proposed.yaml
npx tsx src/cli.ts run --api-map config/api-map.yaml --params config/params.csv
npx tsx src/cli.ts report --run output/runs/latest
```